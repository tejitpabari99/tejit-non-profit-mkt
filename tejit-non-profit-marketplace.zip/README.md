# Tejit's Non Profit Tools (Claude plugin marketplace)

Small, guided Claude helpers for nonprofits, created by Tejit Pabari.

## Install (Claude Code)
```
/plugin marketplace add tejitpabari99/tejit-non-profit-marketplace
/plugin install tejit-non-profit@tejit-non-profit-marketplace
```
Then say **"Tejit's non profit tools"** to get started. Turn on auto-update: `/plugin` → Marketplaces → tejit-non-profit-marketplace → Enable auto-update.

## Skills
- **Partner Event Finder**: finds where partner organizations announce fundraising events and adds them to a shared Google Calendar.

See `plugins/tejit-non-profit/CHANGELOG.md` for versions.
